export const devolverOpcionSeleccionada = (opcion) => {
    if(opcion === '1'){return 'agendar un turno';}
    if(opcion === '2'){return 'alquilar un departamento';} 
    if(opcion === '3'){return 'reclamar por mi comida';} 
    if(opcion === '4'){return 'mal funcionamiento de internet';}
    
  }